#include<stdio.h>
int main(){
int monitored_data = 0;
int store_data = 0;
int trigger_threshold = 4;
for (int a = 2; a > 0; a--){      //第一层循环模拟长时间运行的程序,为了便于观察只设置了2次
    for ( int b = 3; b > 0; b--){ //这一层循环模拟程序每隔一段时间获取一次数据
        monitored_data++;         //自增模拟传感器或者其他源获得的数据 
        if (monitored_data >= trigger_threshold){  //超过阈值，触发数据存储操作（涉及跳转）
            store_data = monitored_data;
            break; 
        }
        store_data = monitored_data; //定时存储（忽略数据的覆盖情况，只做情况示例）
    }
}
    return 0;
}

